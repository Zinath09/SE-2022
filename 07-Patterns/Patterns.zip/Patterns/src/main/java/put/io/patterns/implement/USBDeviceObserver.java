package put.io.patterns.implement;

public class USBDeviceObserver implements SystemStateObserver{
    private Integer lastNumber=-1;
    @Override
    public void update(SystemMonitor monitor) {
        if (lastNumber == -1){
            lastNumber=monitor.getLastSystemState().getUsbDevices();
        }
        if (monitor.getLastSystemState().getUsbDevices()!= lastNumber){
            System.out.println("MESSAGE: There has been a change in a number of USB devices.");
        }
        lastNumber=monitor.getLastSystemState().getUsbDevices();
    }
}
